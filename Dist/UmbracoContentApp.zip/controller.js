angular
  .module("umbraco")
  .controller("$safeitemname$.Controller", function($scope) {
    var vm = this;

    //your code here
  });
