﻿//https://our.umbraco.com/Documentation/Reference/Routing/WebApi/

using Umbraco.Web.WebApi;

namespace $webnamespace$
{
    //Route: ~/Umbraco/Api/[YourControllerName]
    public class $itemname$ : UmbracoApiController
    {
        
    }
}